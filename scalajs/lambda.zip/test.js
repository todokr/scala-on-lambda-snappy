exports.testHandler = function(event) {
  console.log(event);
  console.log("test!")
};